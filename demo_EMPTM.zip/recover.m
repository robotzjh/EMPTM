function   pM= recover(pM,M,i)
  
pM(i).M= M*pM(i).M;
